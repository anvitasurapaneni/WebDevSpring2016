/**
 * Created by paulomimahidharia on 2/19/16.
 */
"use strict";
(function(){
    angular
        .module("NoteSpace")
        .controller("SidebarController", SidebarController);

    function SidebarController($scope){

    }
})();